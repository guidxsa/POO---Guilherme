F = int(input('Digite a temperatura em Fahrenheit:'))

C = 5 * (F - 32) / 9

print('A temperatura em C é de', C)